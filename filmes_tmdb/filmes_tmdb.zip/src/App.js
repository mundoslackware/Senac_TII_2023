import Rotas from './routes'


function App() {
  return (
    <div className='col-sm-12'>
      <Rotas />
    </div>
  );
}

export default App;
