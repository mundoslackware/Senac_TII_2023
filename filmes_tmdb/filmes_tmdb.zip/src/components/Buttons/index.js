
import './estilo.botao.css'
export default function ButtonsForm(){
    return(

        <div>
            <button className='botao'>Cadastrar</button>
        </div>
    )
}