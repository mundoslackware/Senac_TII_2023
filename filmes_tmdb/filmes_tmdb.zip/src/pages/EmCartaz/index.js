

export default function EmCartaz(){
    return(
        <div>
            <h1>Em Cartaz</h1>
        </div>
    )
}