

export default function Estreias(){
    return(
        <div>
            <h1>Estréias</h1>
        </div>
    )
}