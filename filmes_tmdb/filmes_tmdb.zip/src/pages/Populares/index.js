

export default function Populares(){
    return(
        <div>
            <h1>Populares</h1>
        </div>
    )
}